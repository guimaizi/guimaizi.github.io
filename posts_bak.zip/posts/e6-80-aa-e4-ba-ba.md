---
title: 怪人
url: 531.html
id: 531
comments: false
categories:
  - 思想
  - 生活
date: 2019-09-22 21:40:02
tags:
---

![](https://raw.githubusercontent.com/guimaizi/cloud/test/img20190922213312.png) 既然当不了正常人那就没办法了，就做个帅气的怪人，变得愈加强大后迟早会找到怪人团队。