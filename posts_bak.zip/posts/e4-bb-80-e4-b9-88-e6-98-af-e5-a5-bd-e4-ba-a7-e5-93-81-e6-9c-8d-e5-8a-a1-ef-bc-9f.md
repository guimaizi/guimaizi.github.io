---
title: 什么是好产品/服务？
url: 160.html
id: 160
comments: false
categories:
  - a股/金融
date: 2018-04-18 21:16:35
tags:
---

**如何寻找好产品？**

![](http://oswqkbo28.bkt.gdipper.com/0CC9993D-8B32-428E-B192-F82CEAE77EC8.png)

  

**一个好产品会带来什么？下面这幅图是不是和茅台很相似？**

  

![](http://oswqkbo28.bkt.gdipper.com/68B61B53-D446-4CE0-95BA-6E51C34CF221.png)