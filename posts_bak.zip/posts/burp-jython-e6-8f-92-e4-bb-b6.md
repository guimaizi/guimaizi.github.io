---
title: burp-jython-插件
date: 2020-06-06T22:23:20+08:00
draft: true
---

功能:把burp获取的数据转换为json保存进tmp.json(有个bug、可能因为java的原因，保存的json数据是单引号，非标准json格式，需要re.sub('\\'','\\"',f.read())把单引号转为双引号，如图二。）

![](http://oswqkbo28.bkt.gdipper.com/2.png)

![](http://oswqkbo28.bkt.gdipper.com/1.png)

  

\# coding: utf-8
'''
@author: guimaizi
'''
from burp import IBurpExtender
from burp import IContextMenuFactory
from burp import IBurpExtenderCallbacks
from burp import IContextMenuInvocation
from burp import IHttpRequestResponse
from javax.swing import JMenuItem
import os

class BurpExtender(IBurpExtender,  IContextMenuFactory):
    
    def registerExtenderCallbacks(self, callbacks):
        self.\_actionName = "test\_vul"
        self._helers = callbacks.getHelpers()
        self._callbacks = callbacks
        callbacks.setExtensionName("test_vul")
        callbacks.registerContextMenuFactory(self)
        return 

    def createMenuItems(self, invocation):
        menu = \[\]
        responses = invocation.getSelectedMessages()
        if len(responses) == 1:
            menu.append(JMenuItem(self._actionName, None , actionPerformed= lambda x, inv=invocation: self.Action(inv)))
            return menu
        return None

    def Action(self, invocation):
        request = invocation.getSelectedMessages().pop()
        analyzedRequest = self._helers.analyzeRequest(request)
        url = analyzedRequest.url
        body = ""
        cookie = ""
        referer = ""
        useragent = ""
        headers = analyzedRequest.getHeaders()
        for header in headers:
            if header.startswith("Cookie: "):
                cookie = header.replace("Cookie: ","")
            elif header.startswith("Referer: "):
                referer = header.replace("Referer: ","")
            elif header.startswith("User-Agent: "):
                useragent = header.replace("User-Agent: ","")
        if analyzedRequest.getMethod() == "POST":
            body = request.getRequest().tostring()\[analyzedRequest.getBodyOffset():\]
        test\_vul = "E:/hack/burp\_lib/test_vul.py"        
        cmd={"url":str(url),"body":str(body),"cookie":str(cookie),"useragent":str(useragent),"referer":str(referer)}
        print cmd
        fo = open("E:/hack/burp_lib/tmp.json", "w")
        fo.write(str(cmd))
        fo.close()
        os.system('start cmd /k '+test_vul)