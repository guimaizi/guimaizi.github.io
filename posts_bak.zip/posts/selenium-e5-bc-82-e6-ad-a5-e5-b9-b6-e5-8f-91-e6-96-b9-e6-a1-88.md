---
title: selenium异步并发方案
url: 550.html
id: 550
comments: false
categories:
  - 安全/代码
date: 2019-10-24 21:20:04
tags:
---

selenium异步并发方案 python3版

    # coding: utf-8
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.common.exceptions import TimeoutException
    from selenium.webdriver.support.ui import WebDriverWait
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.binary_location = r'%s'%"/Applications/Chromium.app/Contents/MacOS/Chromium"
    driver = webdriver.Chrome(executable_path="/Users/guimaizi/hack-tool/chromedriver",options=chrome_options)
    list_url=['https://www.w3school.com.cn/js/js_loop_for.asp','http://www.voidcn.com/article/p-stvclize-bte.html',
              'https://xiday.com/2019/09/21/puppeteer-run-js/','https://im.qq.com/','http://192.168.0.225/vul/frame221.html','https://en.mail.qq.com/','https://www.1688.com/',
          'https://github.com/','https://www.baidu.com/','http://www.guimaizi.com/','https://fanyi.baidu.com/?aldtype=16047#auto/zh','http://es6.ruanyifeng.com/#docs/promise',
      'https://security.alibaba.com/','https://security.alipay.com/home.htm','https://security.pingan.com/','https://bugbounty.huawei.com/hbp/#/home','https://www.youtube.com/watch?v=N0bypyMIt6w']
    driver.get('http://www.qq.com')
    for url in list_url:
        js="window.open('%s')"%url
        driver.execute_script(js)
    windows = driver.window_handles
    for num in windows:
        try:
            driver.switch_to.window(num)
            driver.set_script_timeout(5)
            #driver.set_page_load_timeout(5)
            print(driver.title)
        except Exception as e:
            print(e)
        finally:
            driver.close()
    driver.quit()