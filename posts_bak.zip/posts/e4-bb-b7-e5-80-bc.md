---
title: 价值
url: 186.html
id: 186
comments: false
categories:
  - a股/金融
date: 2018-05-01 09:00:35
tags:
---

价值无处不在，价值不是恒定的，价值一直在变，但最终都会变得合理。

![](http://oswqkbo28.bkt.gdipper.com/11111.png)

红线是趋势

蓝线是波动

无论是波动还是趋势都在寻找着合理区间。