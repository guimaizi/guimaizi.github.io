---
title: 对自己对别人仁慈点
url: 396.html
id: 396
comments: false
categories:
  - 生活
date: 2019-01-27 18:16:30
tags:
---

![](https://raw.githubusercontent.com/guimaizi/cloud/test/img/1.png) ![](https://raw.githubusercontent.com/guimaizi/cloud/test/img/2.png) ![](https://raw.githubusercontent.com/guimaizi/cloud/test/img/3.png) ![](https://raw.githubusercontent.com/guimaizi/cloud/test/img/4.png) ![](https://raw.githubusercontent.com/guimaizi/cloud/test/img/5.png) ![](https://raw.githubusercontent.com/guimaizi/cloud/test/img/20190127181917.png) ![](https://raw.githubusercontent.com/guimaizi/cloud/test/img/7.png) ![](https://raw.githubusercontent.com/guimaizi/cloud/test/img/8.png)