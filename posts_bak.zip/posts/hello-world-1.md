---
title: about
date: 2018-01-23 11:55:41
tags: About Blog
---

> 深山中，似寻常 似深寂 似磅礴，一眼望去尽是空。  
> 意境中，时嗔痴 时机妙 时沸腾，一念过去尽是空。  
> 生来不受拘束，一生追梦，纵横人世间24载，愿尝试各种乐趣。

擅长挖掘事物本质，想出自己的看法。 研究a股，专注于企业模式、行业模式等各种商业模式的各种研究。 熟悉python\\php\\java\\c\\c++\\汇编\\mysql\\javascript，web、pc、Android等计算机相关都有所了解,在2017以前一直研究信息安全。  
如对本人感兴趣、意见，可通过以下方式联系。  
微信(wechat) :  
![F10y28.png](https://s1.ax1x.com/2018/12/06/F10y28.png)

twitter: [@guimaizi]([twitter](https://twitter.com/guimaizi))
E-mail : admin@guimaizi.com