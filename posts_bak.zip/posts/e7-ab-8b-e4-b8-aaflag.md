---
title: 立个flag
url: 519.html
id: 519
comments: false
categories:
  - 生活
date: 2019-08-25 22:37:34
tags:
---

虽然很大概率不能完成，但还是要立。 十一点前睡觉、七点半前起床。  
早晚出门遛弯、中途好好学习、好好码代码、好好挖漏洞。 认真、执着、坚持、善良。