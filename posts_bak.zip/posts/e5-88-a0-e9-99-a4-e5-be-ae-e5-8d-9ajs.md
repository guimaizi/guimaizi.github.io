---
title: 删除微博js
url: 564.html
id: 564
comments: false
categories:
  - 安全/代码
date: 2019-11-12 10:50:44
tags:
---

    function delWeibo() {
      if (!document.querySelectorAll('.screen_box a')[0]) return false;
      if (1) {
        document.querySelectorAll('.screen_box a')[0].click();
        if (!document.querySelectorAll('.screen_box ul li a')[0]) return false;
        document.querySelectorAll('.screen_box ul li a')[0].click();
        if (!document.querySelectorAll('.btn a.W_btn_a')[0]) return false;
        document.querySelectorAll('.btn a.W_btn_a')[0].click();
      }
    }
    setInterval(window.scrollTo(0,document.body.scrollHeight), 1000);
    setInterval(window.scrollTo(0,document.body.scrollHeight), 1000);
    window.onload = setInterval(delWeibo, 1000);