---
title: 从小事做起
url: 494.html
id: 494
comments: false
categories:
  - 思想
  - 生活
date: 2019-07-15 21:18:40
tags:
---

![](https://raw.githubusercontent.com/guimaizi/cloud/test/20190715211730.jpg) 人心浮躁,总想做改天换地的大事,那么小事谁做?千里之行始于足下,从小事做起,好高骛远总会根基不稳当到达一个高度导致整体崩塌,又成长了。